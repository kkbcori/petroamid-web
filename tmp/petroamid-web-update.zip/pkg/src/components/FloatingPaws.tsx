// Subtle ambient background animation — soft floating paw prints
// Deliberately slow and gentle so it doesn't distract
import React, { useEffect } from 'react';
import { injectAnimationStyles } from '../utils/animations';

// Spread across bottom portion of screen only, low opacity
const PAWS = [
  { em: '🐾', left: 5,  top: 72, size: 13, dur: 7.0, delay: 0   },
  { em: '🐾', left: 20, top: 80, size: 11, dur: 8.5, delay: 1.5 },
  { em: '🐾', left: 38, top: 68, size: 15, dur: 6.5, delay: 0.8 },
  { em: '🐾', left: 55, top: 78, size: 12, dur: 9.0, delay: 2.2 },
  { em: '🐾', left: 72, top: 70, size: 14, dur: 7.5, delay: 1.0 },
  { em: '🐾', left: 88, top: 75, size: 11, dur: 8.0, delay: 3.0 },
];

export default function FloatingPaws() {
  useEffect(() => { injectAnimationStyles(); }, []);
  return (
    <div style={{ position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 0, overflow: 'hidden' }}>
      {PAWS.map((p, i) => (
        <span key={i} style={{
          position:       'absolute',
          left:           `${p.left}%`,
          top:            `${p.top}%`,
          fontSize:       `${p.size}px`,
          opacity:        0.07,           // very subtle — barely visible
          animation:      `floatUp ${p.dur}s ease-in-out infinite`,
          animationDelay: `${p.delay}s`,
          willChange:     'transform',
        }}>{p.em}</span>
      ))}
    </div>
  );
}
