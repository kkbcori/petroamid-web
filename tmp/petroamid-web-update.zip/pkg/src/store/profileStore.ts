import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';

export interface Profile {
  id: string;
  displayName: string;
  avatarEmoji: string;
  createdAt: string;
}

interface ProfileStore {
  profiles: Profile[];
  activeProfileId: string | null;
  activeProfile: () => Profile | undefined;
  createProfile: (displayName: string, avatarEmoji?: string) => Profile;
  switchProfile: (id: string) => void;
  updateProfile: (id: string, updates: Partial<Profile>) => void;
  deleteProfile: (id: string) => void;
  logout: () => void;
}

export const useProfileStore = create<ProfileStore>()(
  persist(
    (set, get) => ({
      profiles: [],
      activeProfileId: null,

      activeProfile: () => {
        const { profiles, activeProfileId } = get();
        return profiles.find(p => p.id === activeProfileId);
      },

      createProfile: (displayName, avatarEmoji = '👤') => {
        const profile: Profile = {
          id: Math.random().toString(36).slice(2),
          displayName, avatarEmoji,
          createdAt: new Date().toISOString(),
        };
        set(s => ({
          profiles: [...s.profiles, profile],
          activeProfileId: profile.id,
        }));
        return profile;
      },

      switchProfile: (id) => set({ activeProfileId: id }),

      updateProfile: (id, updates) =>
        set(s => ({ profiles: s.profiles.map(p => p.id === id ? { ...p, ...updates } : p) })),

      deleteProfile: (id) =>
        set(s => ({
          profiles: s.profiles.filter(p => p.id !== id),
          activeProfileId: s.activeProfileId === id
            ? (s.profiles.find(p => p.id !== id)?.id ?? null)
            : s.activeProfileId,
        })),

      logout: () => set({ activeProfileId: null }),
    }),
    { name: 'petroamid-profiles', storage: createJSONStorage(() => localStorage) }
  )
);
