// ─────────────────────────────────────────────────────────────────────────────
// PetRoamID — Design tokens
// ─────────────────────────────────────────────────────────────────────────────

export const Colors = {
  // Backgrounds
  navy:       '#0f172a',
  navyMid:    '#1e293b',
  navyLight:  '#263347',

  // Text
  cream:      '#f1f5f9',
  creammid:   '#94a3b8',

  // Borders / shadows
  border:      'rgba(255,255,255,0.08)',
  borderLight: 'rgba(255,255,255,0.04)',
  shadow:      'rgba(0,0,0,0.4)',

  // Semantic colours
  green:   '#22c55e',
  yellow:  '#eab308',
  red:     '#ef4444',
  orange:  '#f97316',
  blue:    '#3b82f6',
  teal:    '#2A9D8F',
  gold:    '#d97706',

  // Tinted backgrounds
  greenBg:  'rgba(34,197,94,0.12)',
  redBg:    'rgba(239,68,68,0.12)',
  orangeBg: 'rgba(249,115,22,0.12)',
  yellowBg: 'rgba(234,179,8,0.12)',
  blueBg:   'rgba(59,130,246,0.12)',
  tealBg:   'rgba(42,157,143,0.12)',
  tealGlow: 'rgba(42,157,143,0.25)',
  goldLight: 'rgba(217,119,6,0.15)',
};

// Global CSS injected once into <head>
export const globalCSS = `
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  html, body, #root {
    height: 100%;
    background-color: ${Colors.navy};
    color: ${Colors.cream};
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    -webkit-font-smoothing: antialiased;
  }

  button { font-family: inherit; }
  input, select, textarea { font-family: inherit; outline: none; }
  a { color: inherit; }

  ::-webkit-scrollbar { width: 6px; }
  ::-webkit-scrollbar-track { background: transparent; }
  ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.12); border-radius: 3px; }

  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@600;700&display=swap');
`;
