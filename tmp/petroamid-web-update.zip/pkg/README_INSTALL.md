# PetRoamID Web — Installation Guide

## How to use this package

1. Unzip this file into a temporary folder
2. Copy the contents INTO your existing `petroamid-web` project folder
   (overwrite when asked — these are updated versions of existing files)
3. Run the following in your project root:

```bash
npm install
npm run dev
```

## What's included

```
src/
  App.tsx                          ← Routes (6 tabs incl. Stays + Vets)
  main.tsx                         ← Entry point
  pages/
    DashboardPage.tsx              ← Home (floating paws, animated cards)
    PetsPage.tsx                   ← My Pets
    AddPetPage.tsx                 ← Add/Edit pet form
    TripSetupPage.tsx              ← New Trip (searchable origin, dest grid)
    ChecklistPage.tsx              ← Checklist (confetti at 100%)
    ProfilePage.tsx                ← Profile setup
    StaysPage.tsx                  ← Pet-friendly stays map
    VetsPage.tsx                   ← Nearby vets map
  components/
    Layout.tsx                     ← 6-item nav (Home/Pets/NewTrip/Stays/Vets/Settings)
    Illustrations.tsx              ← PageBanner + all scene exports
    FloatingPaws.tsx               ← Ambient paw animation (Dashboard)
  utils/
    animations.ts                  ← CSS keyframes + confetti + ripple utilities
    overpassClient.ts              ← Nominatim geocoding (with country bias fix)
    timelineCalculator.ts          ← Business logic (timeline, readiness score)
    theme.ts                       ← Design tokens / colors
  store/
    appStore.ts                    ← Pet/trip/vaccination CRUD (Zustand + persist)
    profileStore.ts                ← Multi-profile management
    AppContext.tsx                 ← React context provider
  data/
    travelRequirements.ts          ← US/CA/EU/AU/NZ/JP checklist rules (2025)
  assets/
    logo.jpg
    scene-airport.png
    scene-backpack.png
    scene-cats.png
    scene-hug.png
    scene-plane.png
    scene-walk.png
    scene-stay.png                 ← NEW (Stays page banner)
    scene-vet.png                  ← NEW (Vets page banner)
public/
  logo.jpg
  404.html                         ← GitHub Pages SPA redirect fix
  scene-stay.png
  scene-vet.png
tests/
  unit/
    businessLogic.test.ts          ← 125 unit tests (Vitest)
    setup.ts
  e2e/
    petroamid.spec.ts              ← Playwright E2E tests
.github/workflows/
  test.yml                         ← CI (unit tests on push, E2E disabled)
package.json
vite.config.ts
vitest.config.ts
playwright.config.ts
tsconfig.json
```

## Running tests

```bash
# Unit tests (no browser, runs in seconds)
npm run test:unit

# E2E tests (requires dev server)
npm run dev        # in one terminal
npm run test:e2e   # in another terminal
```
